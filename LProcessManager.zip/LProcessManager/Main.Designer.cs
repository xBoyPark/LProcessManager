﻿using System;

namespace LProcessManager
{
    
    partial class LPM
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LPM));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Seq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.State = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Pos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Operate = new System.Windows.Forms.DataGridViewButtonColumn();
            this.startdelay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.showrun_check = new System.Windows.Forms.CheckBox();
            this.alwayup_check = new System.Windows.Forms.CheckBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_allstart = new System.Windows.Forms.Button();
            this.btn_stop = new System.Windows.Forms.Button();
            this.btn_del = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.StateMonitor = new System.Windows.Forms.Timer(this.components);
            this.ProcessMonitorTimer = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.25984F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 78.74016F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1731, 915);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Seq,
            this.DName,
            this.State,
            this.Pos,
            this.Operate,
            this.startdelay});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 197);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 30;
            this.dataGridView1.Size = new System.Drawing.Size(1725, 715);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.Paint += new System.Windows.Forms.PaintEventHandler(this.dataGridView1_Paint);
            // 
            // Seq
            // 
            this.Seq.HeaderText = "序号";
            this.Seq.Name = "Seq";
            this.Seq.Visible = false;
            // 
            // DName
            // 
            this.DName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.DName.DefaultCellStyle = dataGridViewCellStyle1;
            this.DName.HeaderText = "名称";
            this.DName.Name = "DName";
            this.DName.ReadOnly = true;
            this.DName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // State
            // 
            this.State.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.State.DefaultCellStyle = dataGridViewCellStyle2;
            this.State.HeaderText = "状态";
            this.State.Name = "State";
            this.State.ReadOnly = true;
            this.State.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Pos
            // 
            this.Pos.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Pos.DefaultCellStyle = dataGridViewCellStyle3;
            this.Pos.HeaderText = "位置";
            this.Pos.Name = "Pos";
            this.Pos.ReadOnly = true;
            this.Pos.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Operate
            // 
            this.Operate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Operate.HeaderText = "操作";
            this.Operate.Name = "Operate";
            this.Operate.ReadOnly = true;
            // 
            // startdelay
            // 
            this.startdelay.HeaderText = "启动延时(ms)";
            this.startdelay.Name = "startdelay";
            this.startdelay.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.showrun_check);
            this.panel1.Controls.Add(this.alwayup_check);
            this.panel1.Controls.Add(this.btn_save);
            this.panel1.Controls.Add(this.btn_allstart);
            this.panel1.Controls.Add(this.btn_stop);
            this.panel1.Controls.Add(this.btn_del);
            this.panel1.Controls.Add(this.btn_add);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1725, 188);
            this.panel1.TabIndex = 1;
            // 
            // showrun_check
            // 
            this.showrun_check.AutoSize = true;
            this.showrun_check.Location = new System.Drawing.Point(1411, 153);
            this.showrun_check.Name = "showrun_check";
            this.showrun_check.Size = new System.Drawing.Size(106, 22);
            this.showrun_check.TabIndex = 8;
            this.showrun_check.Text = "显示运行";
            this.showrun_check.UseVisualStyleBackColor = true;
            this.showrun_check.CheckedChanged += new System.EventHandler(this.showrun_check_CheckedChanged);
            // 
            // alwayup_check
            // 
            this.alwayup_check.AutoSize = true;
            this.alwayup_check.Location = new System.Drawing.Point(1572, 153);
            this.alwayup_check.Name = "alwayup_check";
            this.alwayup_check.Size = new System.Drawing.Size(106, 22);
            this.alwayup_check.TabIndex = 7;
            this.alwayup_check.Text = "一直运行";
            this.alwayup_check.UseVisualStyleBackColor = true;
            this.alwayup_check.CheckedChanged += new System.EventHandler(this.alwayup_check_CheckedChanged);
            // 
            // btn_save
            // 
            this.btn_save.Location = new System.Drawing.Point(116, 46);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(143, 119);
            this.btn_save.TabIndex = 6;
            this.btn_save.Text = "保存";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_allstart
            // 
            this.btn_allstart.Location = new System.Drawing.Point(787, 46);
            this.btn_allstart.Name = "btn_allstart";
            this.btn_allstart.Size = new System.Drawing.Size(143, 119);
            this.btn_allstart.TabIndex = 5;
            this.btn_allstart.Text = "全部开始/重启";
            this.btn_allstart.UseVisualStyleBackColor = true;
            this.btn_allstart.Click += new System.EventHandler(this.btn_allstart_Click);
            // 
            // btn_stop
            // 
            this.btn_stop.Location = new System.Drawing.Point(1019, 46);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(143, 119);
            this.btn_stop.TabIndex = 2;
            this.btn_stop.Text = "全部结束";
            this.btn_stop.UseVisualStyleBackColor = true;
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            // 
            // btn_del
            // 
            this.btn_del.Location = new System.Drawing.Point(561, 46);
            this.btn_del.Name = "btn_del";
            this.btn_del.Size = new System.Drawing.Size(143, 119);
            this.btn_del.TabIndex = 1;
            this.btn_del.Text = "删除";
            this.btn_del.UseVisualStyleBackColor = true;
            this.btn_del.Click += new System.EventHandler(this.btn_del_Click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(321, 46);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(143, 119);
            this.btn_add.TabIndex = 0;
            this.btn_add.Text = "添加";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "ofd";
            // 
            // StateMonitor
            // 
            this.StateMonitor.Enabled = true;
            this.StateMonitor.Interval = 200;
            this.StateMonitor.Tick += new System.EventHandler(this.StateMonitor_Timer);
            // 
            // ProcessMonitorTimer
            // 
            this.ProcessMonitorTimer.Enabled = true;
            this.ProcessMonitorTimer.Interval = 3000;
            this.ProcessMonitorTimer.Tick += new System.EventHandler(this.ProcessMonitorTimer_Tick);
            // 
            // LPM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1731, 915);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LPM";
            this.Text = "LProcess Manager1.0";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.LPM_FormClosing);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.Button btn_del;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btn_allstart;
        private System.Windows.Forms.Timer StateMonitor;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.DataGridViewTextBoxColumn Seq;
        private System.Windows.Forms.DataGridViewTextBoxColumn DName;
        private System.Windows.Forms.DataGridViewTextBoxColumn State;
        private System.Windows.Forms.DataGridViewTextBoxColumn Pos;
        private System.Windows.Forms.DataGridViewButtonColumn Operate;
        private System.Windows.Forms.DataGridViewTextBoxColumn startdelay;
        private System.Windows.Forms.CheckBox alwayup_check;
        private System.Windows.Forms.CheckBox showrun_check;
        private System.Windows.Forms.Timer ProcessMonitorTimer;
        //private System.Windows.Forms.DataGridViewTextBoxColumn Name;
    }
}

