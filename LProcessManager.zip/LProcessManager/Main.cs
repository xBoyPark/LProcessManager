﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using VLog;

namespace LProcessManager
{

    public partial class LPM : Form
    {
        private string[] States = { "就绪","正在运行","已停止",""};
        private string[] OpStr = { "启动", "停止" };
        private static string LCfgName = "LPM_CFG.cfg";
        private vLog pmlog { get; set; }
        private ProcessWindowStyle processWindowStyle { get; set; }
        public LPM()
        {
            InitializeComponent();
            pmlog = new vLog(@"./log/");
            vseq = 0;
            pmlog.writelog("***进程管理器启动***",0);
            //加载配置文件
            using (FileStream LFile = new FileStream(@"./LPM_CFG.cfg",
            FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read))
            {
                if(LFile.Length>8)
                {
                    Byte[] initList = new Byte[LFile.Length];
                    int actLen = LFile.Read(initList, 0, (int)LFile.Length);
                    string DataViewStr = System.Text.Encoding.UTF8.GetString(initList);
                    string[] strarray = new string[] { "$-Legendary-^" };
                    string[] DataViewRowStrs = DataViewStr.Split(strarray, StringSplitOptions.RemoveEmptyEntries);
                    foreach(string x in DataViewRowStrs)
                    {
                        string[] cells = x.Split(";".ToCharArray(),StringSplitOptions.None);
                        AddRow(dataGridView1, cells[1], States[0], cells[3], int.Parse(cells[0]));
                    }
                    
                }
            }
            dataGridView1.ClearSelection();
            processWindowStyle = ProcessWindowStyle.Hidden;


        }
        private void AddRow(DataGridView vdgb,string name,string state,string pos,int seq,string op="")
        {
            int _index = vdgb.Rows.Add();//新建一行
            int j = 0;
            vdgb.Rows[_index].Cells[j].Value = seq;
            vdgb.Rows[_index].Cells[j + 1].Value = name;
            vdgb.Rows[_index].Cells[j + 2].Value = state;
            vdgb.Rows[_index].Cells[j + 3].Value = pos;
            vdgb.Rows[_index].Cells[j + 5].Value = 1000;//默认
        
            Button vbtn = new Button();
            vbtn.Name = name;
            vbtn.Text = OpStr[0];

            vbtn.Click += (s,e)=>Vbtn_Click(vdgb.Rows[_index],vbtn);
          
            vdgb.Controls.Add(vbtn);
            var rt = vdgb.GetCellDisplayRectangle(4, _index, true);
            vbtn.Location = new Point(rt.Location.X,rt.Location.Y);
            vbtn.Width = rt.Width;
            vbtn.Height = rt.Height;

            //vdgb.Rows[_index].Cells[j + 4].Value= OpStr[0];

        }
        /// <summary>
        /// 启动或者结束进程
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="arg1"></param>
        private void Vbtn_Click(object sender,object arg1)
        {
            dataGridView1.ClearSelection();
            DataGridViewRow _vdr = (DataGridViewRow)sender;
            Button _btn = (Button)arg1;
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = @""+_vdr.Cells[3].Value+_vdr.Cells[1].Value;
            psi.Arguments = "";
            psi.Verb = "runas";
            psi.WindowStyle = processWindowStyle;
            psi.WorkingDirectory = @"" + _vdr.Cells[3].Value;
            string proName = _vdr.Cells[1].Value.ToString();
            var _pro = Process.GetProcessesByName(_vdr.Cells[1].Value.ToString().Substring(0, _vdr.Cells[1].Value.ToString().Length - 4));

            if (_btn.Text.Trim().Equals(OpStr[0]))
            {
                if(_pro.Length==1)
                {
                    pmlog.writelog("进程"+ _vdr.Cells[1].Value.ToString()+"已经启动",0);
                    _vdr.Cells[2].Value = States[1];
                    _btn.Text = OpStr[1];
                    return;
                }
                
                Process pro = Process.Start(psi);

                if (pro != null)
                {
                    bool proflag = pro.WaitForExit(int.Parse(_vdr.Cells[5].Value.ToString()));
                    if (proflag == false)
                    {
                        _vdr.Cells[2].Value = States[1];
                        _btn.Text = OpStr[1];
                        pmlog.writelog("进程" + _vdr.Cells[1].Value.ToString() + "启动成功", 0);
                    }
                    else
                        _vdr.Cells[2].Value = States[3];
                }
                else if (pro.HasExited)
                {

                }
                else
                {
                    _vdr.Cells[2].Value = States[2];
                    _btn.Text = OpStr[0];
                }
            }
            else
            {
                //var _pro = Process.GetProcessesByName(_vdr.Cells[1].Value.ToString().Substring(0, _vdr.Cells[1].Value.ToString().Length-4));
                if (_pro.Length <= 0)
                {
                    pmlog.writelog("进程" + _vdr.Cells[1].Value.ToString() + "已经停止",1);
                    _vdr.Cells[2].Value = States[2];
                    _btn.Text = OpStr[0];
                    return;
                }
                if (proName.Contains("CommManager"))
                {
                    DialogResult commrs = MessageBox.Show("是否结束CommManager.exe?", "提示", MessageBoxButtons.OKCancel);
                    if (commrs != DialogResult.OK)
                    {
                       
                        return;
                    }
                    else
                    {
                        pmlog.writelog("用户点击确定结束CommManager.exe", 1);
                    }
                }
                _pro[0].Kill();

                _pro[0].WaitForExit(int.Parse(_vdr.Cells[5].Value.ToString()));

                if(_pro[0].HasExited)
                {
                    _vdr.Cells[2].Value = States[2];
                    _btn.Text = OpStr[0];
                    pmlog.writelog("进程" + _vdr.Cells[1].Value.ToString() + "结束成功", 0);
                }

            }
           
            
           
        }

        public DataTable gDts { get; set; }
        public int vseq { get; set; }
        private void btn_add_Click(object sender, EventArgs e)
        {
            pmlog.writelog("用户点击添加按钮开始", 0);
            openFileDialog1.InitialDirectory = "D:\\";
            openFileDialog1.Filter = "All files (*.exe)|*.exe";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;
            openFileDialog1.Multiselect = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string[] resultFileNames = openFileDialog1.SafeFileNames;
                string path = openFileDialog1.FileName.Substring(0,openFileDialog1.FileName.LastIndexOf('\\')+1);
                foreach (var f in resultFileNames)
                {
                    pmlog.writelog("用户选择了应用:"+f, 0);
                    vseq++;
                    AddRow(dataGridView1, f, States[0], path, vseq,OpStr[0]);
                }

            }
            dataGridView1.ClearSelection();
            pmlog.writelog("用户点击添加按钮结束", 0);
        }

        private void dataGridView1_Paint(object sender, PaintEventArgs e)
        {

           // for (int _index = 0; _index < dataGridView1.Rows; _index++)
            foreach (DataGridViewRow r in dataGridView1.Rows)
            {
                var rt = dataGridView1.GetCellDisplayRectangle(4, r.Index, true);
                string _nameBtn = r.Cells[1].Value.ToString();
                foreach (var ctrlbtn in dataGridView1.Controls)
                {
                    string str = ctrlbtn.GetType().Name;
                    if (str == "Button")
                    {
                        Button __btn = (Button)ctrlbtn;
                        str = __btn.Name;
                        str = __btn.Text;
                        if (__btn.Name == _nameBtn)
                        {
                            __btn.Location = new Point(rt.Location.X, rt.Location.Y);
                            __btn.Width = rt.Width;
                            __btn.Height = rt.Height;
                        }
                    }
                }

            }
           
        }
        private void btn_Test(object sender, EventArgs e)
        {
            MessageBox.Show("fun1");
        }
        private void btn_Test1(object sender, EventArgs e)
        {
            MessageBox.Show("fun2");
        }
        /// <summary>
        /// 删除选中维护的进程，当且仅当进程不是正在运行的状态
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_del_Click(object sender, EventArgs e)
        {
            pmlog.writelog("用户点击删除按钮", 0);
            List<DataGridViewRow> _delIndex = new List<DataGridViewRow>();
            List<Control> _delCon = new List<Control>();
            
            foreach (DataGridViewRow r in dataGridView1.Rows)
            {
                if (!r.IsNewRow)
                {
                    if (r.Selected)
                    {
                        _delIndex.Add(r);
                    }
                    foreach (var ctrlbtn in dataGridView1.Controls)
                    {
                        string str = ctrlbtn.GetType().Name;
                        if (str.Equals("Button"))
                        {
                            Button __btn = (Button)ctrlbtn;
                            str = __btn.Name;

                            if (str.Equals(r.Cells[1].Value.ToString()))
                            {
                                _delCon.Add((Control)ctrlbtn);
                                break;
                            }

                        }
                    }
                }
            }
            
            foreach (DataGridViewRow r in _delIndex)
            {
                var _pro = Process.GetProcessesByName(r.Cells[1].Value.ToString().Substring(0, r.Cells[1].Value.ToString().Length - 4));
                if (_pro.Length > 0)
                {
                    MessageBox.Show("无法删除正在运行的进程，请先停止后再进行删除操作");
                    continue;
                }
                else
                {
                    dataGridView1.Rows.Remove(r);
                    pmlog.writelog("用户删除了进程" + r.Cells[1].Value.ToString() + "成功", 0);
                }
            }
            foreach (var ctrlbtn in _delCon)
            {
                dataGridView1.Controls.Remove(ctrlbtn);//全部移除
            }
            dataGridView1.ClearSelection();

            //重新绑定
            foreach (DataGridViewRow r in dataGridView1.Rows)
            {
                if (r.IsNewRow)
                { continue; }
                string _btn_t = r.Cells[1].Value.ToString();
                if (_btn_t.Trim().Length == 0)
                { continue; }

                Button vbtn = new Button();
                vbtn.Name = r.Cells[1].Value.ToString();
                vbtn.Text = r.Cells[2].Value.ToString().Contains("正在运行") ? OpStr[1] : OpStr[0];

                vbtn.Click += (s, w) => Vbtn_Click(r, vbtn);
                dataGridView1.Controls.Add(vbtn);
                var rt = dataGridView1.GetCellDisplayRectangle(4, r.Index, true);
                vbtn.Location = new Point(rt.Location.X, rt.Location.Y);
                vbtn.Width = rt.Width;
                vbtn.Height = rt.Height;
            }
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            pmlog.writelog("用户点击结束按钮", 0);
            DialogResult userClick = MessageBox.Show("是否结束全部应用程序?", "提示", MessageBoxButtons.OKCancel);
            if(userClick==DialogResult.OK)
            {
                foreach(DataGridViewRow r in dataGridView1.Rows)
                {
                    string proName = r.Cells[1].Value.ToString();
                    if(proName.Length==0)
                    { continue; }

                    var _pro = Process.GetProcessesByName(proName.Substring(0, proName.Length - 4));
                    if (_pro.Length <= 0)
                    {
                        //MessageBox.Show("进程" + proName + "已经停止");
                        pmlog.writelog("进程" + proName + "已经停止",1);
                        r.Cells[2].Value = States[2];
                        continue;
                    }
                    if(proName.Contains("CommManager"))
                    {
                        DialogResult commrs =  MessageBox.Show("是否结束CommManager.exe?", "提示", MessageBoxButtons.OKCancel);
                        if (commrs != DialogResult.OK)
                        {

                            continue;
                        }
                        else
                        {
                            pmlog.writelog("用户点击确定 结束CommManager.exe", 1);
                        }
                    }
                    _pro[0].Kill();

                    _pro[0].WaitForExit(int.Parse(r.Cells[5].Value.ToString()));

                    if (_pro[0].HasExited)
                    {
                        r.Cells[2].Value = States[2];
                        //_btn.Text = OpStr[0];
                    }
                }
               
                foreach(var x in dataGridView1.Controls)
                {
                    if(x.GetType().ToString().Contains("Button"))
                    {
                        Button xbtn = (Button)x;
                        xbtn.Text = OpStr[0];
                    }
                }
                return;
            }
            else
            {
                return;
            }
        }

        private void btn_restart_Click(object sender, EventArgs e)
        {
            pmlog.writelog("用户点击全部重新启动按钮", 0);
            DialogResult userClick = MessageBox.Show("是否启动全部应用程序?", "提示", MessageBoxButtons.OKCancel);
            if (userClick == DialogResult.OK)
            {
                foreach (DataGridViewRow r in dataGridView1.Rows)
                {
                    string proName = r.Cells[1].Value.ToString();
                    if (proName.Length == 0)
                    { continue; }

                    var _pro = Process.GetProcessesByName(proName.Substring(0, proName.Length - 4));
                    if (_pro.Length > 0)
                    {
                        _pro[0].Kill();

                        _pro[0].WaitForExit(int.Parse(r.Cells[5].Value.ToString()));

                        if (_pro[0].HasExited)
                        {
                            r.Cells[2].Value = States[2];
                           
                        }
                       
                    }
                    foreach (var ctrlbtn in dataGridView1.Controls)
                    {
                        string str = ctrlbtn.GetType().Name;
                        if (str.Contains("Button"))
                        {
                            Button __btn = (Button)ctrlbtn;
                            str = __btn.Name;

                            if (str.Equals(r.Cells[1].Value.ToString()))
                            {
                                __btn.Text = OpStr[0];
                                Vbtn_Click(r, __btn);
                               
                            }

                        }
                    }
                }
                 
                


                

                return;
            }
            else
            {
                return;
            }
        }

        private void btn_allstart_Click(object sender, EventArgs e)
        {
            btn_restart_Click(sender, e);
        }

        private void StateMonitor_Timer(object sender, EventArgs e)
        {
            foreach(DataGridViewRow r in dataGridView1.Rows)
            {
                if (r.IsNewRow) continue;
                string proName = "";
                string proState = "";
                string proBtnState = "";
                proName = r.Cells[1].Value.ToString();
                proState = r.Cells[2].Value.ToString();
                Button __btn = null;
                foreach (var ctrlbtn in dataGridView1.Controls)
                {
                    string str = ctrlbtn.GetType().Name;
                    if (str.Contains("Button"))
                    {
                        __btn = (Button)ctrlbtn;
                        str = __btn.Name;

                        if (str.Equals(proName))
                        {
                            proBtnState=__btn.Text;
                            break;
                        }

                    }
                }
                var _pro = Process.GetProcessesByName(proName.Substring(0, proName.Length - 4));
                if (_pro.Length ==1)
                {
                    
                    proState = States[1];
                    proBtnState = OpStr[1];
                    r.Cells[2].Style.BackColor = Color.Green;
                }
                else
                {
                    proState = proState.Equals("就绪")==false?States[2]: proState;
                    proBtnState = OpStr[0];
                    r.Cells[2].Style.BackColor = Color.Silver;
                }
                __btn.Text = proBtnState;
                r.Cells[2].Value = proState;
            }


            if (alwayup_check.Checked)
            {
                btn_del.Enabled = false;
                btn_allstart.Enabled = false;
                btn_stop.Enabled = false;
                foreach (DataGridViewRow r in dataGridView1.Rows)
                {
                    if (r.IsNewRow) continue;
                    string proName = "";
                    proName = r.Cells[1].Value.ToString();
                    Button __btn = null;
                    foreach (var ctrlbtn in dataGridView1.Controls)
                    {
                        string str = ctrlbtn.GetType().Name;
                        if (str.Contains("Button"))
                        {
                            __btn = (Button)ctrlbtn;
                            str = __btn.Name;

                            if (str.Equals(proName))
                            {
                                __btn.Enabled = false;
                                break;
                            }

                        }
                    }
                }

            }
            else
            {
                btn_del.Enabled = true;
                btn_allstart.Enabled = true;
                btn_stop.Enabled = true;
                foreach (DataGridViewRow r in dataGridView1.Rows)
                {
                    if (r.IsNewRow) continue;
                    string proName = "";
                    proName = r.Cells[1].Value.ToString();
                    Button __btn = null;
                    foreach (var ctrlbtn in dataGridView1.Controls)
                    {
                        string str = ctrlbtn.GetType().Name;
                        if (str.Contains("Button"))
                        {
                            __btn = (Button)ctrlbtn;
                            str = __btn.Name;

                            if (str.Equals(proName))
                            {
                                __btn.Enabled = true;
                                break;
                            }

                        }
                    }
                }

            }
        }
       
        private byte[] GetBytes(DataGridViewRow vr,int vRowId)
        {
            if(vr!=null)
            {
                Button _vtbn = GetBtnByViewRow(vr);
                if (_vtbn == null) return null;
                string byteStr = "";
                for(int i=0;i<vr.Cells.Count;i++)
                {
                    if(i!=4)
                    {
                        byteStr += vr.Cells[i].Value.ToString() + ";";
                    }
                    else
                    {
                        byteStr += _vtbn.Text + ";";
                    }
                }

                byteStr += "$-Legendary-^";
                Byte[] byteArray = System.Text.Encoding.UTF8.GetBytes(byteStr);
                return byteArray;
            }
            else
            {
                return null;
            }
        }
        private void btn_save_Click(object sender, EventArgs e)
        {
         
            File.Delete(@"./LPM_CFG.cfg");
            using (FileStream LFile = new FileStream(@"./LPM_CFG.cfg",
            FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read))
            {
                int pointerPos = 0;
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    var _tempbytes = GetBytes(dataGridView1.Rows[i], i);
                    LFile.Write(_tempbytes, pointerPos, _tempbytes.Length);
                    LFile.Flush();
                }
            }
        }


        private Button GetBtnByViewRow(DataGridViewRow vr)
        {
            Button __btn = null;
            string proName = vr.Cells[1].Value.ToString();
            foreach (var ctrlbtn in dataGridView1.Controls)
            {
                string str = ctrlbtn.GetType().Name;
                if (str.Contains("Button"))
                {
                    __btn = (Button)ctrlbtn;
                    str = __btn.Name;

                    if (str.Equals(proName))
                    {
                        return __btn;
                    }

                }
            }

            return null;
        }

        private void LPM_FormClosing(object sender, FormClosingEventArgs e)
        {
            btn_save_Click(sender, e);
        }

        private void btn_ProInfo(object sender, EventArgs e)
        {
            //foreach (DataGridViewRow r in dataGridView1.Rows)
            //{
            //    if (r.IsNewRow) continue;
            //    string proName = "";
            //    proName = r.Cells[1].Value.ToString();
            //    var _pro = Process.GetProcessesByName(proName.Substring(0, proName.Length - 4));
            //    if (_pro.Length > 0)
            //    {
            //        _pro[0].hid.MainWindowHandle;
            //        //.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
            //    }
            //}
        }

        private void showrun_check_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("只有在重启应用程序时生效");

            CheckBox _showcheck = (CheckBox)sender;
            if(_showcheck==null)
            {
                return;
            }
            else
            {
                if (_showcheck.Checked)
                {
                    processWindowStyle = ProcessWindowStyle.Normal;
                }
                else
                {
                    processWindowStyle = ProcessWindowStyle.Hidden;
                }
            }
           

        }

        private void ProcessMonitorTimer_Tick(object sender, EventArgs e)
        {
            if (alwayup_check.Checked)
            {

                foreach (DataGridViewRow r in dataGridView1.Rows)
                {
                    if (r.IsNewRow) continue;
                    string proName = "";
                    proName = r.Cells[1].Value.ToString();
                    var _pro = Process.GetProcessesByName(proName.Substring(0, proName.Length - 4));
                    if (_pro.Length>1 || _pro.Length<=0)
                    {
                       
                        foreach (var ctrlbtn in dataGridView1.Controls)
                        {
                            string str = ctrlbtn.GetType().Name;
                            if (str.Contains("Button"))
                            {
                                Button __btn = (Button)ctrlbtn;
                                str = __btn.Name;

                                if (str.Equals(r.Cells[1].Value.ToString()))
                                {
                                    __btn.Text = OpStr[0];
                                    Vbtn_Click(r, __btn);
                                    break;
                                }

                            }
                        }
                    }
                    if(_pro.Length==1)
                    {
                        if(_pro[0].HasExited)
                        {
                            foreach (var ctrlbtn in dataGridView1.Controls)
                            {
                                string str = ctrlbtn.GetType().Name;
                                if (str.Contains("Button"))
                                {
                                    Button __btn = (Button)ctrlbtn;
                                    str = __btn.Name;

                                    if (str.Equals(r.Cells[1].Value.ToString()))
                                    {
                                        __btn.Text = OpStr[0];
                                        Vbtn_Click(r, __btn);
                                        break;
                                    }

                                }
                            }
                        }
                    }
                  
                }
            }
        }

        private void alwayup_check_CheckedChanged(object sender, EventArgs e)
        {
            if(alwayup_check.Checked)
            {
                btn_del.Enabled = false;
                btn_allstart.Enabled = false;
                btn_stop.Enabled = false;
                foreach (DataGridViewRow r in dataGridView1.Rows)
                {
                    if (r.IsNewRow) continue;
                    string proName = "";
                    proName = r.Cells[1].Value.ToString();
                    Button __btn = null;
                    foreach (var ctrlbtn in dataGridView1.Controls)
                    {
                        string str = ctrlbtn.GetType().Name;
                        if (str.Contains("Button"))
                        {
                            __btn = (Button)ctrlbtn;
                            str = __btn.Name;

                            if (str.Equals(proName))
                            {
                                __btn.Enabled = false;
                                break;
                            }

                        }
                    }
                }

            }
            else
            {
                btn_del.Enabled = true;
                btn_allstart.Enabled = true;
                btn_stop.Enabled = true;
                foreach (DataGridViewRow r in dataGridView1.Rows)
                {
                    if (r.IsNewRow) continue;
                    string proName = "";
                    proName = r.Cells[1].Value.ToString();
                    Button __btn = null;
                    foreach (var ctrlbtn in dataGridView1.Controls)
                    {
                        string str = ctrlbtn.GetType().Name;
                        if (str.Contains("Button"))
                        {
                            __btn = (Button)ctrlbtn;
                            str = __btn.Name;

                            if (str.Equals(proName))
                            {
                                __btn.Enabled = true;
                                break;
                            }

                        }
                    }
                }

            }
        }
    }
}
